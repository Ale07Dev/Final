# Fitness Tracker fixes applied

Applied in this revision:
- Removed hardcoded account IDs from dashboard, history, goals, progress, workout details, and session save paths; screens use the active repository user. Manual workout saving refuses a missing/non-positive user ID.
- Added repository `addGoal` backed by Room insert; goal creation no longer calls `@Update` on ID 0.
- Manual workouts calculate calories using workout type, duration, distance, and entered/profile weight; editing preserves original ID, owner, date, timestamp, GPS/location metadata, and updates editable fields.
- History search filters by workout type and notes; date filter cycles All / 7 days / 30 days; Edit button now opens the edit form instead of details.
- Dashboard calorie and duration metrics now use today's workouts. Progress streak continues from yesterday if no workout has been logged today.
- Theme is only applied when the user changes the switch, not on initial view creation. Export control now gives an explicit message rather than silently doing nothing.
- Login screen clears the fragment back stack and hides bottom navigation; Settings and Session do not add redundant back-stack entries.
- Added missing Retrofit `PUT` import. Removed unused Compose BOM, CardView, and Moshi codegen dependencies.
- Corrected README statements about Supabase/HTTPS to match the current local PHP/MySQL development setup.

## Remaining backend / verification notes
- Profile edits currently update local Room only. A remote profile update requires a matching server endpoint and request/response contract; this project archive does not contain the PHP backend, so that endpoint cannot be safely implemented or verified here.
- CSV export and Personal Records presentation still need implementation; the Export button reports this limitation rather than pretending to export.
- Build verification could not run in this environment because Gradle 8.7 could not be downloaded (network DNS unavailable). Open the project in Android Studio and run Gradle sync / `assembleDebug` to complete compile verification.

## Follow-up fixes (profile sync, records, export, units)

- Added Retrofit `PUT update_profile.php` request/response contract and wired profile edits to the server before updating the Room cache/current-user state. Added `backend_examples/update_profile.php` plus setup notes. **The PHP sample must be aligned with the actual database bootstrap/table columns and deployed to the server**; the PHP backend was not part of the original Android archive.
- Implemented a Personal Records RecyclerView adapter and row layout. Progress now displays the user's longest distance, highest-calorie workout, and longest-duration workout when those records exist.
- Implemented CSV export through Android's system document picker (`CreateDocument`). The export contains the signed-in user's workouts and quotes/escapes CSV fields.
- Integrated the metric/imperial preference into live-session distance/speed displays, workout-list and workout-detail distances, Progress distance totals, and Add Workout distance/weight input conversion. Values continue to be stored internally in kilometres and kilograms.

## Verification status

XML layout files parse successfully and `backend_examples/update_profile.php` passes `php -l`. An Android Gradle build could not be run in this environment because the Gradle wrapper could not resolve `services.gradle.org` (network/DNS unavailable). Please run **Build > Make Project** in Android Studio after syncing dependencies. The profile endpoint also needs to be deployed/configured on your PHP server before remote profile edits can succeed.
