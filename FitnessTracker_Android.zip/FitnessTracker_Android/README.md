# Fitness Tracker Android (Enhanced)

A native Android fitness tracking app built with **Kotlin, XML Views, RecyclerView, Room, Retrofit, and PHP/MySQL**.

## Enhancements over Project 1

- **XML Views only** — No Jetpack Compose. Uses `Activity` + `Fragment` + `RecyclerView`.
- **Live GPS session tracking** — Continuous GPS points, real-time distance, speed, pace, pause/resume/end.
- **Dark theme support** — XML themes (`values/themes.xml` + `values/themes-night.xml`), toggleable in Settings.
- **Configurable API IP** — `BuildConfig.API_BASE_URL` set in `build.gradle.kts`, overridable via `local.properties`.
- **Network security** — cleartext HTTP is currently enabled for local development; configure HTTPS and disable cleartext traffic for production.
- **Remote sync for workout CRUD** — Add/update/delete workouts sync to PHP/MySQL before writing to Room.
- **Password reset** — `resetPasswordForEmail` endpoint via `reset_password.php`.
- **Profile page** — Edit name, email, age, weight.
- **Settings page** — Dark mode toggle, metric/imperial unit toggle, export, sign out.
- **Session page** — Live timer, GPS coordinates, distance, speed, calories.

## Prerequisites

- Android Studio (latest stable)
- JDK 11+
- A self-hosted PHP/MySQL backend (XAMPP works locally; Supabase is not used by this project)
- Android device or emulator (API 24+)

## Get Started

### 1. Open in Android Studio

Open the `FitnessTracker_Android` folder as a project. Let Gradle sync.

### 2. Configure the API URL

The default API base URL is `See `app/build.gradle.kts` and `local.properties` for the configured API base URL; update it to match your PHP server.`. To change it for your network:

```bash
cp local.properties.example local.properties
# Edit local.properties and set API_BASE_URL to your server (e.g., https://192.168.1.50/fitness_api/)
```

Then rebuild. The value is injected into `BuildConfig.API_BASE_URL`.

### 3. Set up the PHP/MySQL backend

Create these endpoints on your PHP server:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `login.php` | POST | Email/password authentication |
| `register.php` | POST | User registration |
| `reset_password.php` | POST | Send password reset link |
| `get_workouts.php` | GET | Fetch workouts for a user |
| `add_workout.php` | POST | Create a workout |
| `update_workout.php` | PUT | Update a workout (remote sync) |
| `delete_workout.php` | DELETE | Delete a workout (remote sync) |

All endpoints must return JSON and use HTTPS.

### 4. Run

Select your device/emulator and click **Run**. The app installs with ID `com.example.fitnessracker` and can run alongside the wireframe project.

## Project Structure

```
FitnessTracker_Android/
├── app/src/main/AndroidManifest.xml        # HTTPS only, cleartext disabled
├── app/src/main/res/
│   ├── values/colors.xml
│   ├── values/themes.xml                   # Light theme
│   ├── values/themes-night.xml             # Dark theme
│   ├── values/strings.xml
│   ├── layout/                             # All XML layouts
│   ├── menu/bottom_nav_menu.xml
│   └── drawable/                           # Vector icons
├── app/src/main/java/com/example/fitnessracker/
│   ├── FitnessApp.kt                       # Application class (holds repository)
│   ├── MainActivity.kt                     # Single Activity, fragment navigation
│   ├── data/model/                         # User, Workout, Goal, WorkoutType, GpsPoint
│   ├── data/local/                         # Room database + DAOs
│   ├── data/remote/                        # Retrofit + HTTPS API service
│   ├── data/repository/                    # Repository + CRUD sync + password reset
│   ├── location/GpsTracker.kt              # Continuous live GPS tracking
│   └── ui/screens/                         # Fragments (Login, Register, Dashboard, ...)
├── app/build.gradle.kts                    # XML Views, no Compose, ViewBinding
├── local.properties.example                # API URL override template
└── README.md
```

## Security Notes

- Passwords are never logged (OkHttp interceptor set to `BASIC`).
- `usesCleartextTraffic="false"` blocks HTTP; use HTTPS in production.
- API key/secrets should never be committed; use `local.properties` (gitignored).

## Test Checklist

- [ ] Register a new account and verify login works
- [ ] Test password reset flow
- [ ] Log a workout manually (add_workout syncs to server)
- [ ] Start a live GPS session, pause/resume, end and save
- [ ] Edit and delete a workout (verify remote sync)
- [ ] Toggle dark mode and units in Settings
- [ ] Edit profile and save
