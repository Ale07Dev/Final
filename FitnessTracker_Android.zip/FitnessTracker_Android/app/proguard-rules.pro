# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.
#
# For more details, see
#   https://developer.android.com/studio/build/shrink-code.html

# Keep Room entities and DAOs
-keep class com.example.fitnessracker.data.model.** { *; }
-keep class com.example.fitnessracker.data.local.** { *; }

# Keep Retrofit interface
-keep interface com.example.fitnessracker.data.remote.FitnessApiService { *; }

# Keep Moshi adapters
-keep class com.squareup.moshi.** { *; }
-keep interface com.squareup.moshi.** { *; }

# Keep ViewModels
-keep class com.example.fitnessracker.ui.viewmodel.** { *; }

# Keep Activities and Fragments
-keep class com.example.fitnessracker.MainActivity { *; }
-keep class com.example.fitnessracker.ui.screens.** { *; }

# Keep native methods
-keepclasseswithmembers class * {
    native <methods>;
}

# Keep names for ViewBinding
-keep class com.example.fitnessracker.databinding.** { *; }

# Suppress warnings
-dontwarn androidx.**
-dontwarn com.squareup.**
-dontwarn com.google.android.**
-dontwarn org.jetbrains.kotlin.**
