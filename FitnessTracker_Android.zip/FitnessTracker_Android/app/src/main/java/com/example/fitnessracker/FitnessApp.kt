package com.example.fitnessracker

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import com.example.fitnessracker.data.local.FitnessDatabase
import com.example.fitnessracker.data.repository.FitnessRepositoryImpl

class FitnessApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Only override the system setting once the user has actually chosen something.
        val prefs = getSharedPreferences("fitness_settings", Context.MODE_PRIVATE)
        if (prefs.contains("dark_mode")) {
            AppCompatDelegate.setDefaultNightMode(
                if (prefs.getBoolean("dark_mode", false)) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
    }

    val repository: FitnessRepositoryImpl by lazy {
        val database = FitnessDatabase.getDatabase(this)
        FitnessRepositoryImpl(
            userDao = database.userDao(),
            workoutDao = database.workoutDao(),
            goalDao = database.goalDao()
        )
    }
}
