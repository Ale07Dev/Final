package com.example.fitnessracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.commit
import com.example.fitnessracker.databinding.ActivityMainBinding
import com.example.fitnessracker.ui.screens.AddWorkoutFragment
import com.example.fitnessracker.ui.screens.DashboardFragment
import com.example.fitnessracker.ui.screens.GoalsFragment
import com.example.fitnessracker.ui.screens.HistoryFragment
import com.example.fitnessracker.ui.screens.LoginFragment
import com.example.fitnessracker.ui.screens.ProgressFragment
import com.example.fitnessracker.ui.screens.ProfileFragment
import com.example.fitnessracker.ui.screens.RegisterFragment
import com.example.fitnessracker.ui.screens.SessionFragment
import com.example.fitnessracker.ui.screens.SettingsFragment
import com.example.fitnessracker.ui.screens.WorkoutDetailFragment
import android.view.View
import com.example.fitnessracker.data.model.Workout

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Setting BottomNavigationView.selectedItemId re-fires the item-selected listener. Without this
    // guard, every showX() (which highlights its tab) would navigate again, recursively.
    private var syncingNav = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val app = application as FitnessApp

        // Auto-route based on auth state
        if (app.repository.isSignedIn) {
            showDashboard()
        } else {
            showLogin()
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            if (syncingNav) return@setOnItemSelectedListener true
            when (item.itemId) {
                R.id.nav_dashboard -> { showDashboard(); true }
                R.id.nav_history -> { showHistory(); true }
                R.id.nav_session -> { showSession(); true }
                R.id.nav_progress -> { showProgress(); true }
                R.id.nav_profile -> { showProfile(); true }
                else -> false
            }
        }
    }

    fun navigateToLogin() {
        showLogin()
    }

    fun editWorkout(workout: Workout) { showAddWorkout(workout) }

    fun navigateToHistory() {
        showHistory()
    }

    // Goals and Settings are opened from the Profile screen (BottomNavigationView holds max 5 items).
    fun navigateToGoals() {
        replaceFragment(GoalsFragment(), addToBackStack = true)
    }

    fun navigateToSettings() {
        replaceFragment(SettingsFragment(), addToBackStack = true)
    }

    fun navigateToWorkoutDetail(workoutId: Long) {
        val fragment = WorkoutDetailFragment()
        val args = android.os.Bundle()
        args.putLong("workout_id", workoutId)
        fragment.arguments = args
        fragment.setCallbacks(
            onDeleteConfirmed = {
                // Return to history after delete
                showHistory()
            },
            onEditRequested = { workout ->
                // Navigate to edit (reuses AddWorkoutFragment with pre-filled data for now)
                showAddWorkout(workout)
            }
        )
        replaceFragment(fragment, addToBackStack = true)
    }

    private fun showLogin() {
        val fragment = LoginFragment().apply {
            setCallbacks(
                onNavigateToRegister = { showRegister() },
                onLoginSuccess = { showDashboard() }
            )
        }
        supportFragmentManager.popBackStack(null, androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE)
        replaceFragment(fragment, addToBackStack = false)
        binding.bottomNav.visibility = View.GONE
    }

    private fun showRegister() {
        val fragment = RegisterFragment().apply {
            setCallbacks(
                onNavigateBack = { showLogin() },
                onRegisterSuccess = { showDashboard() }
            )
        }
        replaceFragment(fragment, addToBackStack = false)
    }

    private fun showDashboard() {
        val fragment = DashboardFragment().apply {
            setCallback(
                onNavigateToAddWorkout = { showAddWorkout(null) },
                onWorkoutClick = { workoutId ->
                    navigateToWorkoutDetail(workoutId)
                }
            )
        }
        replaceFragment(fragment, addToBackStack = false)
        binding.bottomNav.visibility = View.VISIBLE
        selectTab(R.id.nav_dashboard)
    }

    private fun showAddWorkout(workoutToEdit: Workout?) {
        val fragment = AddWorkoutFragment().apply {
            setCallback { showDashboard() }
            if (workoutToEdit != null) {
                setWorkoutToEdit(workoutToEdit)
            }
        }
        replaceFragment(fragment, addToBackStack = false)
    }

    private fun showHistory() {
        replaceFragment(HistoryFragment(), addToBackStack = false)
        binding.bottomNav.visibility = View.VISIBLE
        selectTab(R.id.nav_history)
    }

    private fun showProgress() {
        replaceFragment(ProgressFragment(), addToBackStack = false)
        binding.bottomNav.visibility = View.VISIBLE
        selectTab(R.id.nav_progress)
    }

    private fun showProfile() {
        replaceFragment(ProfileFragment(), addToBackStack = false)
        binding.bottomNav.visibility = View.VISIBLE
        selectTab(R.id.nav_profile)
    }

    private fun showSession() {
        replaceFragment(SessionFragment(), addToBackStack = false)
        binding.bottomNav.visibility = View.VISIBLE
        selectTab(R.id.nav_session)
    }

    private fun selectTab(itemId: Int) {
        if (binding.bottomNav.selectedItemId == itemId) return
        syncingNav = true
        try {
            binding.bottomNav.selectedItemId = itemId
        } finally {
            syncingNav = false
        }
    }

    private fun replaceFragment(fragment: Fragment, addToBackStack: Boolean) {
        // A top-level (tab) destination starts from a clean back stack, otherwise stale
        // "detail"/"goals"/"settings" entries would be replayed by the system Back button.
        if (!addToBackStack && supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        }
        supportFragmentManager.commit {
            replace(R.id.fragment_container, fragment)
            if (addToBackStack) addToBackStack(null)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        if (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
            return true
        }
        return super.onSupportNavigateUp()
    }
}
