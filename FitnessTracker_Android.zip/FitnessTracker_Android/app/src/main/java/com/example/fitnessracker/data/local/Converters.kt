
package com.example.fitnessracker.data.local

import androidx.room.TypeConverter

class Converters {

    @TypeConverter
    fun fromDate(value: Long?): String? {
        return value?.toString()
    }

    @TypeConverter
    fun toDate(value: String?): Long? {
        return value?.toLongOrNull()
    }
}
