
package com.example.fitnessracker.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val title: String,
    val targetValue: Int,
    val currentValue: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
