package com.example.fitnessracker.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.fitnessracker.data.model.User

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User): Long

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Long): User?

    @Query("SELECT * FROM users WHERE email = :email")
    suspend fun getUserByEmail(email: String): User?

    @Query("UPDATE users SET name = :name, email = :email, age = :age, weightKg = :weightKg WHERE id = :id")
    suspend fun updateUser(id: Long, name: String, email: String, age: Int, weightKg: Double)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUser(id: Long)
}
