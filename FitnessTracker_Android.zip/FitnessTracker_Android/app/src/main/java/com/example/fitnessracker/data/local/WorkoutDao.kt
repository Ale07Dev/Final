package com.example.fitnessracker.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.fitnessracker.data.model.Workout
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkout(workout: Workout): Long

    @Update
    suspend fun updateWorkout(workout: Workout)

    @Delete
    suspend fun deleteWorkout(workout: Workout)

    @Query("SELECT * FROM workouts WHERE userId = :userId ORDER BY timestamp DESC")
    fun getWorkoutsByUser(userId: Long): Flow<List<Workout>>

    @Query("SELECT * FROM workouts WHERE userId = :userId AND date = :date ORDER BY timestamp DESC")
    fun getWorkoutsForDate(userId: Long, date: String): Flow<List<Workout>>

    @Query("""
        SELECT * FROM workouts
        WHERE userId = :userId
        AND date >= :startDate AND date <= :endDate
        ORDER BY timestamp DESC
    """)
    fun getWorkoutsByDateRange(userId: Long, startDate: String, endDate: String): Flow<List<Workout>>

    @Query("SELECT DISTINCT workoutType FROM workouts WHERE userId = :userId")
    fun getWorkoutTypes(userId: Long): Flow<List<String>>
}
