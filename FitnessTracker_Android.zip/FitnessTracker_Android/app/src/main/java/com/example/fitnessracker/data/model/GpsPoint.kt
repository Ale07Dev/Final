package com.example.fitnessracker.data.model

data class GpsPoint(
    val latitude: Double,
    val longitude: Double,
    val altitude: Double = 0.0,
    val speedMs: Float = 0f,
    val timestamp: Long = System.currentTimeMillis()
)
