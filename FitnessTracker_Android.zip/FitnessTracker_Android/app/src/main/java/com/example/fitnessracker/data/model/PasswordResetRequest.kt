package com.example.fitnessracker.data.model

data class PasswordResetRequest(
    val email: String
)

data class PasswordResetResponse(
    val success: Boolean,
    val message: String = ""
)
