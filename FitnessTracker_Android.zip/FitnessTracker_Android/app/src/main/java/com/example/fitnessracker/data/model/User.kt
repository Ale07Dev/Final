package com.example.fitnessracker.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String = "",
    val email: String,
    val passwordHash: String = "",
    val age: Int = 30,
    val weightKg: Double = 70.0,
    val createdAt: Long = System.currentTimeMillis(),
    val isGuest: Boolean = false
)
