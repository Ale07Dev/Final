package com.example.fitnessracker.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "workouts",
    indices = [Index(value = ["userId"]), Index(value = ["date"])]
)
data class Workout(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long = 1,
    val workoutType: String = "Running",
    val date: String = "", // yyyy-MM-dd
    val durationMinutes: Int = 0,
    val distanceKm: Double? = null,
    val caloriesBurned: Int = 0,
    val notes: String = "",
    val rpe: Int? = null,
    val locationName: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
)
