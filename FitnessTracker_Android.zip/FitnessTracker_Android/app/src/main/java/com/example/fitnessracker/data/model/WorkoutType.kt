package com.example.fitnessracker.data.model

enum class WorkoutType(
    val displayName: String,
    val requiresDistance: Boolean,
    val defaultCaloriesPerMinute: Double,
    val isOutdoorCompatible: Boolean
) {
    RUNNING("Running", true, 11.5, true),
    CYCLING("Cycling", true, 9.0, true),
    WEIGHTLIFTING("Weightlifting", false, 6.5, false),
    SWIMMING("Swimming", true, 10.0, false),
    WALKING("Walking", true, 4.2, true),
    YOGA("Yoga", false, 3.8, false);

    companion object {
        fun fromString(name: String): WorkoutType {
            return entries.firstOrNull { it.displayName.equals(name, ignoreCase = true) } ?: RUNNING
        }
    }
}
