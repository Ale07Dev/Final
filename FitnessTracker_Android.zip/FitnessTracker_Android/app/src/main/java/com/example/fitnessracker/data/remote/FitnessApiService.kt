package com.example.fitnessracker.data.remote

import com.example.fitnessracker.data.remote.dto.ApiResponse
import com.example.fitnessracker.data.remote.dto.LoginRequestDto
import com.example.fitnessracker.data.remote.dto.LoginResponseDto
import com.example.fitnessracker.data.remote.dto.PhpUserDto
import com.example.fitnessracker.data.remote.dto.ProfileUpdateDto
import com.example.fitnessracker.data.remote.dto.RegisterRequestDto
import com.example.fitnessracker.data.remote.dto.RegisterResponseDto
import com.example.fitnessracker.data.remote.dto.WorkoutDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Query

/**
 * Retrofit API contract for the PHP/MySQL web service.
 *
 * All requests use HTTPS. Base URL is configurable via BuildConfig.API_BASE_URL
 * (see NetworkConfig.kt) so it can be changed for different networks
 * (emulator vs physical device on same Wi-Fi, staging vs production).
 */
interface FitnessApiService {

    @POST("login.php")
    suspend fun login(@Body request: LoginRequestDto): Response<LoginResponseDto>

    @POST("register.php")
    suspend fun register(@Body request: RegisterRequestDto): Response<RegisterResponseDto>

    /**
     * Password reset endpoint.
     * PHP should implement reset_password.php that accepts an email and sends a reset link.
     */
    @FormUrlEncoded
    @POST("reset_password.php")
    suspend fun resetPassword(@Field("email") email: String): Response<ApiResponse<Any>>

    @PUT("update_profile.php")
    suspend fun updateProfile(@Body request: ProfileUpdateDto): Response<ApiResponse<Any>>

    @GET("get_workouts.php")
    suspend fun getWorkouts(@Query("user_id") userId: Long): Response<List<WorkoutDto>>

    @POST("add_workout.php")
    suspend fun addWorkout(@Body workout: WorkoutDto): Response<WorkoutDto>

    @PUT("update_workout.php")
    suspend fun updateWorkout(@Body workout: WorkoutDto): Response<WorkoutDto>

    @DELETE("delete_workout.php")
    suspend fun deleteWorkout(@Query("workout_id") workoutId: Long): Response<ApiResponse<Any>>
}
