package com.example.fitnessracker.data.remote.dto

data class LoginRequestDto(
    val email: String,
    val password: String
)

data class LoginResponseDto(
    val success: Boolean,
    val message: String = "",
    val user: PhpUserDto? = null
)

data class PhpUserDto(
    val id: Long,
    val username: String,
    val email: String
)

data class RegisterRequestDto(
    val username: String,
    val email: String,
    val password: String
)

data class RegisterResponseDto(
    val success: Boolean,
    val message: String = "",
    val user: PhpUserDto? = null
)

data class WorkoutDto(
    val id: Long? = null,
    val user_id: Long,
    val workout_type: String,
    val date: String,
    val duration_minutes: Int,
    val distance_km: Double? = null,
    val calories_burned: Int,
    val notes: String? = null,
    val rpe: Int? = null,
    val location_name: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val timestamp: Long
)

data class ApiResponse<T>(
    val success: Boolean,
    val message: String = "",
    val data: T? = null
)

data class PhpApiResponse<T>(
    val success: Boolean,
    val message: String = ""
)
