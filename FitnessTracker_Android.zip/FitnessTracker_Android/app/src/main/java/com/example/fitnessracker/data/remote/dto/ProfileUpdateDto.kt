package com.example.fitnessracker.data.remote.dto

data class ProfileUpdateDto(
    val user_id: Long,
    val username: String,
    val email: String,
    val age: Int,
    val weight_kg: Double
)
