package com.example.fitnessracker.data.repository

import com.example.fitnessracker.data.model.User

object CalorieUtils {
    private val MET_VALUES = mapOf(
        "running" to 9.8,
        "run" to 9.8,
        "cycling" to 8.0,
        "cycle" to 8.0,
        "biking" to 8.0,
        "swimming" to 7.0,
        "swim" to 7.0,
        "walking" to 3.8,
        "walk" to 3.8,
        "weightlifting" to 5.0,
        "weights" to 5.0,
        "yoga" to 3.8
    )

    fun calculateCalories(type: String, durationMinutes: Int, distanceKm: Double, weightKg: Double): Int {
        val met = MET_VALUES[type.lowercase()] ?: 6.0
        val durationHours = durationMinutes / 60.0
        val baseCalories = met * weightKg * durationHours
        val bonusForDistance = distanceKm * 30.0
        return Math.max(10, (baseCalories + bonusForDistance).toInt())
    }
}
