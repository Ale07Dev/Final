package com.example.fitnessracker.data.repository

import com.example.fitnessracker.data.model.Goal
import com.example.fitnessracker.data.model.User
import com.example.fitnessracker.data.model.Workout
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface FitnessRepository {
    val currentUser: StateFlow<User?>
    val isSignedIn: Boolean

    suspend fun login(email: String, password: String): Result<User>
    suspend fun register(name: String, email: String, password: String): Result<User>
    suspend fun resetPassword(email: String): Result<Unit>
    fun loginAsGuest(): User
    fun logout()

    fun getWorkouts(userId: Long): Flow<List<Workout>>
    fun getWorkoutsForDate(userId: Long, date: String): Flow<List<Workout>>
    fun getWorkoutsByDateRange(userId: Long, startDate: String, endDate: String): Flow<List<Workout>>
    fun getGoals(userId: Long): Flow<List<Goal>>
    fun getActiveGoal(userId: Long): Flow<Goal?>

    suspend fun addWorkout(workout: Workout): Result<Long>
    suspend fun updateWorkout(workout: Workout): Result<Unit>
    suspend fun deleteWorkout(workout: Workout): Result<Unit>
    suspend fun updateUser(id: Long, name: String, email: String, age: Int, weightKg: Double): Result<Unit>
    suspend fun addGoal(goal: Goal): Result<Long>
    suspend fun updateGoal(goal: Goal): Result<Unit>

    fun calculateCalories(type: String, durationMinutes: Int, distanceKm: Double, weightKg: Double): Int
}
