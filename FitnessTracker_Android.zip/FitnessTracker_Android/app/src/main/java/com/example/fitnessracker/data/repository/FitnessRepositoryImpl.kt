package com.example.fitnessracker.data.repository

import com.example.fitnessracker.data.local.FitnessDatabase
import com.example.fitnessracker.data.local.GoalDao
import com.example.fitnessracker.data.local.UserDao
import com.example.fitnessracker.data.local.WorkoutDao
import com.example.fitnessracker.data.model.Goal
import com.example.fitnessracker.data.model.User
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.data.remote.FitnessApiService
import com.example.fitnessracker.data.remote.RetrofitClient
import com.example.fitnessracker.data.remote.dto.ProfileUpdateDto
import com.example.fitnessracker.data.remote.dto.LoginRequestDto
import com.example.fitnessracker.data.remote.dto.LoginResponseDto
import com.example.fitnessracker.data.remote.dto.PhpUserDto
import com.example.fitnessracker.data.remote.dto.RegisterRequestDto
import com.example.fitnessracker.data.remote.dto.RegisterResponseDto
import com.example.fitnessracker.data.remote.dto.WorkoutDto
import com.example.fitnessracker.utils.NetworkConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class FitnessRepositoryImpl(
    private val userDao: UserDao,
    private val workoutDao: WorkoutDao,
    private val goalDao: GoalDao,
    private val apiService: FitnessApiService = RetrofitClient.fitnessApiService
) : FitnessRepository {

    private val _currentUser = MutableStateFlow<User?>(null)
    override val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    override val isSignedIn: Boolean
        get() = _currentUser.value != null

    override suspend fun login(email: String, password: String): Result<User> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.login(LoginRequestDto(email = email.trim(), password = password))

            if (response.isSuccessful) {
                val body = response.body()
                if (body != null && body.success && body.user != null) {
                    val phpUser = body.user
                    val domainUser = User(
                        id = phpUser.id,
                        name = phpUser.username,
                        email = phpUser.email,
                        createdAt = System.currentTimeMillis()
                    )
                    _currentUser.value = domainUser

                    try {
                        val existing = userDao.getUserById(phpUser.id)
                        if (existing == null) {
                            userDao.insertUser(domainUser.copy(passwordHash = ""))
                        }
                    } catch (e: Exception) {
                        // Local cache best-effort
                    }

                    return@withContext Result.success(domainUser)
                } else {
                    return@withContext Result.failure(
                        Exception(body?.message ?: "Login failed. Please check your email and password.")
                    )
                }
            } else {
                return@withContext Result.failure(
                    Exception("Login failed: Server returned HTTP ${response.code()}. Please check your API URL and network.")
                )
            }
        } catch (e: Exception) {
            val friendlyError = when (e) {
                is ConnectException ->
                    "Unable to connect to PHP backend at ${NetworkConfig.BASE_URL}. Ensure XAMPP is running and your device is on the same Wi-Fi."
                is SocketTimeoutException ->
                    "Connection timed out to ${NetworkConfig.BASE_URL}. Check firewall and network connectivity."
                is UnknownHostException ->
                    "Host unreachable: ${NetworkConfig.BASE_URL}. Check Wi-Fi connection."
                is IOException -> "Network error: ${e.message}"
                else -> "Login error: ${e.message}"
            }
            return@withContext Result.failure(Exception(friendlyError))
        }
    }

    override suspend fun register(name: String, email: String, password: String): Result<User> = withContext(Dispatchers.IO) {
        if (name.isBlank() || email.isBlank() || password.isBlank()) {
            return@withContext Result.failure(Exception("Name, email and password are required."))
        }
        if (password.length < 6) {
            return@withContext Result.failure(Exception("Password must be at least 6 characters."))
        }

        try {
            val response = apiService.register(
                RegisterRequestDto(username = name.trim(), email = email.trim(), password = password)
            )

            if (!response.isSuccessful) {
                return@withContext Result.failure(
                    Exception("Registration failed: server returned HTTP ${response.code()}.")
                )
            }

            val body = response.body()
            if (body == null || !body.success) {
                return@withContext Result.failure(
                    Exception(body?.message ?: "The server did not confirm account creation.")
                )
            }

            val remoteUser = body.user ?: run {
                val loginResponse = apiService.login(LoginRequestDto(email = email.trim(), password = password))
                val loginBody = loginResponse.body()
                if (!loginResponse.isSuccessful || loginBody == null || !loginBody.success || loginBody.user == null) {
                    return@withContext Result.failure(
                        Exception("Account created, but could not start session. Please log in.")
                    )
                }
                loginBody.user
            }

            val registeredUser = User(
                id = remoteUser.id,
                name = remoteUser.username,
                email = remoteUser.email,
                createdAt = System.currentTimeMillis()
            )

            try {
                val existing = userDao.getUserById(registeredUser.id)
                if (existing == null) userDao.insertUser(registeredUser.copy(passwordHash = ""))
            } catch (e: Exception) {
                // Local cache best-effort
            }

            _currentUser.value = registeredUser
            Result.success(registeredUser)
        } catch (e: Exception) {
            val friendlyError = when (e) {
                is ConnectException -> "Unable to reach the PHP server. Check XAMPP and network."
                is SocketTimeoutException -> "The registration request timed out."
                is UnknownHostException -> "The PHP server could not be found."
                is IOException -> "Network error during registration: ${e.message}"
                else -> "Registration failed: ${e.message ?: "unexpected error"}"
            }
            Result.failure(Exception(friendlyError))
        }
    }

    override suspend fun resetPassword(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (email.isBlank()) {
            return@withContext Result.failure(Exception("Please enter your email address."))
        }
        try {
            val response = apiService.resetPassword(email)
            if (response.isSuccessful) {
                val body = response.body()
                if (body != null && body.success) {
                    return@withContext Result.success(Unit)
                } else {
                    return@withContext Result.failure(
                        Exception(body?.message ?: "Password reset request failed.")
                    )
                }
            } else {
                return@withContext Result.failure(
                    Exception("Password reset failed: HTTP ${response.code()}. Ensure reset_password.php exists on the server.")
                )
            }
        } catch (e: Exception) {
            val friendlyError = when (e) {
                is ConnectException -> "Unable to connect to server for password reset."
                is SocketTimeoutException -> "Password reset request timed out."
                is UnknownHostException -> "Host unreachable for password reset."
                is IOException -> "Network error during password reset: ${e.message}"
                else -> "Password reset error: ${e.message}"
            }
            return@withContext Result.failure(Exception(friendlyError))
        }
    }

    override fun loginAsGuest(): User {
        val guestUser = User(
            id = -1,
            name = "Guest User",
            email = "guest@fitness.local",
            isGuest = true,
            createdAt = System.currentTimeMillis()
        )
        _currentUser.value = guestUser
        return guestUser
    }

    override fun logout() {
        _currentUser.value = null
    }

    override fun getWorkouts(userId: Long): Flow<List<Workout>> {
        return workoutDao.getWorkoutsByUser(userId)
    }

    override fun getWorkoutsForDate(userId: Long, date: String): Flow<List<Workout>> {
        return workoutDao.getWorkoutsForDate(userId, date)
    }

    override fun getWorkoutsByDateRange(userId: Long, startDate: String, endDate: String): Flow<List<Workout>> {
        return workoutDao.getWorkoutsByDateRange(userId, startDate, endDate)
    }

    override fun getGoals(userId: Long): Flow<List<Goal>> {
        return goalDao.getGoalsByUser(userId)
    }

    override fun getActiveGoal(userId: Long): Flow<Goal?> {
        return goalDao.getActiveGoal(userId)
    }

    override suspend fun addWorkout(workout: Workout): Result<Long> = withContext(Dispatchers.IO) {
        try {
            // 1. Save locally first (offline-first)
            val localId = workoutDao.insertWorkout(workout)

            // 2. Best-effort sync to remote PHP/MySQL. The workout is already saved locally,
            //    so being offline / server errors must not turn this into a failure.
            try {
                val dto = WorkoutDto(
                    user_id = workout.userId,
                    workout_type = workout.workoutType,
                    date = workout.date,
                    duration_minutes = workout.durationMinutes,
                    distance_km = workout.distanceKm,
                    calories_burned = workout.caloriesBurned,
                    notes = workout.notes,
                    rpe = workout.rpe,
                    location_name = workout.locationName,
                    latitude = workout.latitude,
                    longitude = workout.longitude,
                    timestamp = workout.timestamp
                )
                apiService.addWorkout(dto)
            } catch (e: Exception) {
                // In production, queue this for retry when back online
            }

            Result.success(localId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateWorkout(workout: Workout): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Remote sync FIRST (edit/delete must sync to MySQL)
            val dto = WorkoutDto(
                id = workout.id,
                user_id = workout.userId,
                workout_type = workout.workoutType,
                date = workout.date,
                duration_minutes = workout.durationMinutes,
                distance_km = workout.distanceKm,
                calories_burned = workout.caloriesBurned,
                notes = workout.notes,
                rpe = workout.rpe,
                location_name = workout.locationName,
                latitude = workout.latitude,
                longitude = workout.longitude,
                timestamp = workout.timestamp
            )
            val syncResponse = apiService.updateWorkout(dto)
            if (!syncResponse.isSuccessful) {
                return@withContext Result.failure(
                    Exception("Remote sync failed: HTTP ${syncResponse.code()}. Workout not updated.")
                )
            }

            // Then update local Room
            workoutDao.updateWorkout(workout)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun deleteWorkout(workout: Workout): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Remote sync FIRST (delete from MySQL)
            val syncResponse = apiService.deleteWorkout(workout.id)
            if (!syncResponse.isSuccessful) {
                return@withContext Result.failure(
                    Exception("Remote delete failed: HTTP ${syncResponse.code()}. Workout not deleted.")
                )
            }

            // Then delete from local Room
            workoutDao.deleteWorkout(workout)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun updateUser(id: Long, name: String, email: String, age: Int, weightKg: Double): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.updateProfile(
                ProfileUpdateDto(user_id = id, username = name.trim(), email = email.trim(), age = age, weight_kg = weightKg)
            )
            val body = response.body()
            if (!response.isSuccessful || body?.success != true) {
                return@withContext Result.failure(Exception(body?.message?.takeIf { it.isNotBlank() } ?: "Profile update failed on server (HTTP ${response.code()}). Local profile was not changed."))
            }
            userDao.updateUser(id, name.trim(), email.trim(), age, weightKg)
            val current = _currentUser.value
            if (current != null && current.id == id) {
                _currentUser.value = current.copy(name = name.trim(), email = email.trim(), age = age, weightKg = weightKg)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("Could not sync profile with server: ${e.message ?: "network error"}"))
        }
    }

    override suspend fun addGoal(goal: Goal): Result<Long> = withContext(Dispatchers.IO) {
        try { Result.success(goalDao.insertGoal(goal)) } catch (e: Exception) { Result.failure(e) }
    }

    override suspend fun updateGoal(goal: Goal): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            goalDao.updateGoal(goal)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun calculateCalories(type: String, durationMinutes: Int, distanceKm: Double, weightKg: Double): Int {
        return CalorieUtils.calculateCalories(type, durationMinutes, distanceKm, weightKg)
    }
}
