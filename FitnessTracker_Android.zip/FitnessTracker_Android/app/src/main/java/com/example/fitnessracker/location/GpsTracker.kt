package com.example.fitnessracker.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import com.example.fitnessracker.data.model.GpsPoint

class GpsTracker(private val context: Context) : LocationListener {

    interface LocationUpdateListener {
        fun onLocationUpdated(location: Location, currentDistanceKm: Double, pointCount: Int)
        fun onGpsStatusChanged(isTracking: Boolean, message: String)
    }

    private val locationManager: LocationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    var isTracking: Boolean = false
        private set
    var isPaused: Boolean = false
        private set

    var totalDistanceMeters: Double = 0.0
        private set

    private var lastLocation: Location? = null
    val gpsPoints = mutableListOf<GpsPoint>()
    var listener: LocationUpdateListener? = null

    val totalDistanceKm: Double
        get() = totalDistanceMeters / 1000.0

    @SuppressLint("MissingPermission")
    fun startTracking(): Boolean {
        try {
            val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            if (!isGpsEnabled && !isNetworkEnabled) {
                listener?.onGpsStatusChanged(false, "GPS and Network location providers disabled")
                return false
            }

            gpsPoints.clear()
            totalDistanceMeters = 0.0
            lastLocation = null
            isTracking = true
            isPaused = false

            if (isGpsEnabled) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    2000L,
                    3f,
                    this
                )
            }
            if (isNetworkEnabled) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    3000L,
                    5f,
                    this
                )
            }

            listener?.onGpsStatusChanged(true, "GPS Tracking active")
            return true
        } catch (e: Exception) {
            listener?.onGpsStatusChanged(false, "GPS Error: ${e.localizedMessage}")
            return false
        }
    }

    fun pauseTracking() {
        if (isTracking && !isPaused) {
            isPaused = true
            listener?.onGpsStatusChanged(true, "GPS Tracking paused")
        }
    }

    fun resumeTracking() {
        if (isTracking && isPaused) {
            isPaused = false
            listener?.onGpsStatusChanged(true, "GPS Tracking active")
        }
    }

    fun stopTracking() {
        try {
            locationManager.removeUpdates(this)
        } catch (e: Exception) {}
        isTracking = false
        isPaused = false
        listener?.onGpsStatusChanged(false, "GPS Tracking stopped")
    }

    override fun onLocationChanged(location: Location) {
        if (!isTracking || isPaused) return

        if (lastLocation != null) {
            val dist = lastLocation!!.distanceTo(location)
            if (dist > 0.5 && dist < 1000.0) {
                totalDistanceMeters += dist
            }
        }
        lastLocation = location

        val point = GpsPoint(
            latitude = location.latitude,
            longitude = location.longitude,
            altitude = location.altitude,
            speedMs = location.speed,
            timestamp = System.currentTimeMillis()
        )
        gpsPoints.add(point)

        listener?.onLocationUpdated(location, totalDistanceKm, gpsPoints.size)
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
