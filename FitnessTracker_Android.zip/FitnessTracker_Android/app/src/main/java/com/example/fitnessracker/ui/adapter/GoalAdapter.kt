package com.example.fitnessracker.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Goal
import com.example.fitnessracker.databinding.ItemGoalBinding

class GoalAdapter(
    private val onGoalClick: (Goal) -> Unit,
    /** (goal, newProgressPercent, isNowCompleted) */
    private val onToggleComplete: (Goal, Int, Boolean) -> Unit
) : ListAdapter<Goal, GoalAdapter.ViewHolder>(GoalDiffCallback()) {

    class ViewHolder(private val binding: ItemGoalBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(goal: Goal, onGoalClick: (Goal) -> Unit, onToggleComplete: (Goal, Int, Boolean) -> Unit) {
            binding.goalTitle.text = goal.title
            binding.goalTarget.text = goal.target
            binding.goalProgress.text = "${goal.currentProgressPercent}%"
            binding.goalProgressBar.progress = goal.currentProgressPercent
            binding.toggleButton.setText(if (goal.isCompleted) R.string.reopen_goal else R.string.mark_done)

            binding.root.setOnClickListener { onGoalClick(goal) }
            binding.toggleButton.setOnClickListener {
                val nowDone = !goal.isCompleted
                onToggleComplete(goal, if (nowDone) 100 else 0, nowDone)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGoalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), onGoalClick, onToggleComplete)
    }

    class GoalDiffCallback : DiffUtil.ItemCallback<Goal>() {
        override fun areItemsTheSame(oldItem: Goal, newItem: Goal): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Goal, newItem: Goal): Boolean = oldItem == newItem
    }
}
