package com.example.fitnessracker.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.fitnessracker.databinding.ItemPersonalRecordBinding

data class PersonalRecord(val title: String, val value: String, val subtitle: String)

class PersonalRecordAdapter : ListAdapter<PersonalRecord, PersonalRecordAdapter.Holder>(Diff) {
    class Holder(private val binding: ItemPersonalRecordBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PersonalRecord) { binding.recordTitle.text = item.title; binding.recordValue.text = item.value; binding.recordSubtitle.text = item.subtitle }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(ItemPersonalRecordBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(getItem(position))
    object Diff : DiffUtil.ItemCallback<PersonalRecord>() {
        override fun areItemsTheSame(a: PersonalRecord, b: PersonalRecord) = a.title == b.title
        override fun areContentsTheSame(a: PersonalRecord, b: PersonalRecord) = a == b
    }
}
