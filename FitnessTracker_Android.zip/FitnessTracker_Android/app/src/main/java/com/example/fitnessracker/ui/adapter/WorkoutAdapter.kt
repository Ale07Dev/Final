package com.example.fitnessracker.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.databinding.ItemWorkoutBinding
import java.util.Locale

class WorkoutAdapter(
    private val onClick: (Workout) -> Unit,
    private val onDelete: (Long) -> Unit,
    private val onEdit: (Workout) -> Unit = onClick
) : ListAdapter<Workout, WorkoutAdapter.ViewHolder>(WorkoutDiffCallback()) {

    class ViewHolder(private val binding: ItemWorkoutBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(workout: Workout, onClick: (Workout) -> Unit, onDelete: (Long) -> Unit, onEdit: (Workout) -> Unit) {
            binding.workoutName.text = workout.workoutType
            binding.workoutDate.text = workout.date
            binding.workoutDuration.text = "${workout.durationMinutes} min"
            val imperial = binding.root.context.getSharedPreferences("fitness_settings", android.content.Context.MODE_PRIVATE).getBoolean("units_imperial", false)
            val distance = workout.distanceKm ?: 0.0
            binding.workoutDistance.text = if (imperial) String.format(Locale.getDefault(), "%.2f mi", distance * 0.621371) else String.format(Locale.getDefault(), "%.2f km", distance)
            binding.workoutCalories.text = "${workout.caloriesBurned} kcal"

            binding.root.setOnClickListener { onClick(workout) }
            binding.editButton.setOnClickListener { onEdit(workout) }
            binding.deleteButton.setOnClickListener { onDelete(workout.id) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemWorkoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), onClick, onDelete, onEdit)
    }

    class WorkoutDiffCallback : DiffUtil.ItemCallback<Workout>() {
        override fun areItemsTheSame(oldItem: Workout, newItem: Workout): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Workout, newItem: Workout): Boolean = oldItem == newItem
    }
}
