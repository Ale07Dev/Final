package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentAddWorkoutBinding
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AddWorkoutFragment : BaseFragment<FragmentAddWorkoutBinding>() {

    private lateinit var repository: FitnessRepository
    private var onNavigateBack: (() -> Unit) = {}
    private var workoutToEdit: Workout? = null

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentAddWorkoutBinding {
        return FragmentAddWorkoutBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        val imperialUnits = requireContext().getSharedPreferences("fitness_settings", android.content.Context.MODE_PRIVATE).getBoolean("units_imperial", false)
        binding.distanceInput.hint = if (imperialUnits) "Distance (miles)" else getString(R.string.distance_km)
        binding.weightInput.hint = if (imperialUnits) "Weight (lb)" else "Weight (kg)"

        // If editing, pre-fill form
        if (workoutToEdit != null) {
            binding.workoutNameInput.setText(workoutToEdit!!.workoutType)
            binding.workoutTypeInput.setText(workoutToEdit!!.workoutType)
            binding.durationInput.setText(workoutToEdit!!.durationMinutes.toString())
            val storedDistance = workoutToEdit!!.distanceKm
            val displayDistance = storedDistance?.let { if (imperialUnits) it * 0.621371 else it }
            binding.distanceInput.setText(displayDistance?.toString() ?: "")
            binding.rpeInput.setText(workoutToEdit!!.rpe?.toString() ?: "")
            binding.weightInput.setText("")
            binding.notesInput.setText(workoutToEdit!!.notes)
            binding.saveWorkoutButton.text = "Update Workout"
        }

        binding.saveWorkoutButton.setOnClickListener {
            val name = binding.workoutNameInput.text.toString().trim()
            val type = binding.workoutTypeInput.text.toString().trim()
            val durationText = binding.durationInput.text.toString().trim()
            val distanceText = binding.distanceInput.text.toString().trim()
            val rpeText = binding.rpeInput.text.toString().trim()
            val weightText = binding.weightInput.text.toString().trim()
            val notes = binding.notesInput.text.toString().trim()

            if (name.isBlank() || type.isBlank() || durationText.isBlank()) {
                Toast.makeText(context, R.string.fill_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val duration = durationText.toIntOrNull() ?: 0
            val prefs = requireContext().getSharedPreferences("fitness_settings", android.content.Context.MODE_PRIVATE)
            val imperial = prefs.getBoolean("units_imperial", false)
            val distanceInputValue = distanceText.toDoubleOrNull()
            val distance = distanceInputValue?.let { if (imperial) it / 0.621371 else it }
            val rpe = rpeText.toIntOrNull()
            val weight = weightText.toDoubleOrNull()
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val userId = repository.currentUser.value?.id
            if (userId == null || userId <= 0L) {
                Toast.makeText(context, "Please sign in to save workouts", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val source = workoutToEdit
            val effectiveWeight = weight?.let { if (imperial) it / 2.2046226218 else it } ?: repository.currentUser.value?.weightKg ?: 70.0
            val calories = repository.calculateCalories(type, duration, distance ?: 0.0, effectiveWeight)
            val workout = Workout(
                id = source?.id ?: 0,
                userId = source?.userId ?: userId,
                workoutType = if (name.isBlank()) type else name,
                date = source?.date ?: today,
                durationMinutes = duration,
                distanceKm = distance,
                caloriesBurned = calories,
                notes = notes,
                rpe = rpe,
                locationName = source?.locationName,
                latitude = source?.latitude,
                longitude = source?.longitude,
                timestamp = source?.timestamp ?: System.currentTimeMillis()
            )

            viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                val result = if (workoutToEdit != null) {
                    repository.updateWorkout(workout)
                } else {
                    repository.addWorkout(workout).map { Unit }
                }
                requireActivity().runOnUiThread {
                    result.onSuccess {
                        Toast.makeText(context, if (workoutToEdit != null) "Workout updated!" else "Workout saved!", Toast.LENGTH_SHORT).show()
                        onNavigateBack.invoke()
                    }.onFailure {
                        Toast.makeText(context, result.exceptionOrNull()?.message ?: "Failed to save workout", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    fun setCallback(onNavigateBack: () -> Unit) {
        this.onNavigateBack = onNavigateBack
    }

    fun setWorkoutToEdit(workout: Workout) {
        this.workoutToEdit = workout
    }
}
