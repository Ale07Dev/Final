package com.example.fitnessracker.ui.screens

import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.viewbinding.ViewBinding
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

abstract class BaseFragment<VB : ViewBinding> : Fragment() {

    abstract fun createBinding(inflater: android.view.LayoutInflater, container: ViewGroup?, attachToParent: Boolean): VB

    private var _binding: VB? = null
    protected val binding: VB
        get() = _binding!!

    override fun onCreateView(
        inflater: android.view.LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: android.os.Bundle?
    ): View {
        _binding = createBinding(inflater, container, false)
        return binding.root
    }

    /**
     * Collects this Flow (or StateFlow) while the fragment's view is at least STARTED and
     * stops when it drops below that or the view is destroyed, so [binding] is never touched
     * after onDestroyView. Replacement for LiveData.observe().
     */
    protected fun <T> Flow<T>.collectInView(action: (T) -> Unit) {
        val flow = this
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                flow.collect { action(it) }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
