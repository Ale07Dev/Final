package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.User
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentDashboardBinding
import com.example.fitnessracker.ui.adapter.WorkoutAdapter
import java.text.SimpleDateFormat
import java.util.*

class DashboardFragment : BaseFragment<FragmentDashboardBinding>() {

    private lateinit var repository: FitnessRepository
    private var onNavigateToAddWorkout: (() -> Unit) = {}
    private var onWorkoutClick: ((Long) -> Unit) = {}

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentDashboardBinding {
        return FragmentDashboardBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        binding.addWorkoutFab.setOnClickListener { onNavigateToAddWorkout.invoke() }

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        binding.dateText.text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())

        repository.currentUser.collectInView { user ->
            val name = if (user == null || user.isGuest) "Guest" else user.name
            binding.greetingText.text = getString(R.string.dashboard_hi, name)
        }

        val userId = repository.currentUser.value?.id ?: return
        repository.getWorkouts(userId).collectInView { workouts ->
            val todayWorkouts = workouts.filter { it.date == today }
            val totalCalories = todayWorkouts.sumOf { it.caloriesBurned }
            val totalMinutes = todayWorkouts.sumOf { it.durationMinutes }
            val todayCount = todayWorkouts.size

            binding.metricMinutes.text = "$totalMinutes min"
            binding.metricWorkouts.text = "$todayCount workouts"
            binding.calorieProgressText.text = "$totalCalories / 500 kcal"
            binding.calorieProgressBar.progress = (totalCalories * 100 / 500).coerceIn(0, 100)
            binding.workoutTargetText.text = "Workouts: $todayCount / 1 target"

            if (todayWorkouts.isEmpty()) {
                binding.emptyStateText.visibility = View.VISIBLE
                binding.todayWorkoutsRecycler.visibility = View.GONE
            } else {
                binding.emptyStateText.visibility = View.GONE
                binding.todayWorkoutsRecycler.visibility = View.VISIBLE
                val adapter = WorkoutAdapter(
                    onClick = { workout ->
                        onWorkoutClick.invoke(workout.id)
                    },
                    onDelete = { workoutId ->
                        // Delete handled in history screen
                    }
                )
                adapter.submitList(todayWorkouts)
                binding.todayWorkoutsRecycler.adapter = adapter
                binding.todayWorkoutsRecycler.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())
            }
        }
    }

    fun setCallback(
        onNavigateToAddWorkout: () -> Unit,
        onWorkoutClick: (Long) -> Unit
    ) {
        this.onNavigateToAddWorkout = onNavigateToAddWorkout
        this.onWorkoutClick = onWorkoutClick
    }
}
