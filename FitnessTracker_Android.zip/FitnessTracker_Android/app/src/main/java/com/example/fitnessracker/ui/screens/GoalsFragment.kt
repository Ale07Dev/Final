package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Goal
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentGoalsBinding
import com.example.fitnessracker.ui.adapter.GoalAdapter
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GoalsFragment : BaseFragment<FragmentGoalsBinding>() {

    private lateinit var repository: FitnessRepository

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentGoalsBinding {
        return FragmentGoalsBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        val adapter = GoalAdapter(
            onGoalClick = { /* detail */ },
            onToggleComplete = { goal, progress, isDone ->
                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    val updated = goal.copy(currentProgressPercent = progress, isCompleted = isDone)
                    val result = repository.updateGoal(updated)
                    requireActivity().runOnUiThread {
                        result.onFailure { e ->
                            Toast.makeText(context, e.message ?: "Update failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        )
        binding.goalsRecycler.adapter = adapter
        binding.goalsRecycler.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())

        val userId = repository.currentUser.value?.id ?: return
        repository.getGoals(userId).collectInView { goals ->
            adapter.submitList(goals)
        }

        binding.addGoalButton.setOnClickListener {
            val title = binding.goalTitleInput.text.toString().trim()
            val target = binding.goalTargetInput.text.toString().trim()
            if (title.isBlank()) {
                Toast.makeText(context, "Enter a goal title", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                val goal = Goal(
                    userId = userId,
                    title = title,
                    target = if (target.isBlank()) "Target set" else target,
                    currentProgressPercent = 0,
                    isCompleted = false
                )
                val result = repository.addGoal(goal).map { Unit }
                requireActivity().runOnUiThread {
                    binding.goalTitleInput.setText("")
                    binding.goalTargetInput.setText("")
                    result.onSuccess {
                        Toast.makeText(context, R.string.add_goal_success, Toast.LENGTH_SHORT).show()
                    }.onFailure { e ->
                        Toast.makeText(context, e.message ?: "Failed to add goal", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
