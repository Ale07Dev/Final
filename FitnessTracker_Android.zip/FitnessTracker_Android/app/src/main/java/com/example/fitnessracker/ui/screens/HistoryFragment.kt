package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.MainActivity
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentHistoryBinding
import com.example.fitnessracker.ui.adapter.WorkoutAdapter
import androidx.lifecycle.lifecycleScope
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HistoryFragment : BaseFragment<FragmentHistoryBinding>() {

    private lateinit var repository: FitnessRepository

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentHistoryBinding {
        return FragmentHistoryBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        var allWorkouts: List<Workout> = emptyList()
        var filterDays = 0
        lateinit var adapter: WorkoutAdapter
        fun applyFilters() {
            val query = binding.searchInput.text.toString().trim().lowercase(Locale.getDefault())
            val cutoff = if (filterDays > 0) Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -filterDays) }.time else null
            val filtered = allWorkouts.filter { workout ->
                (query.isBlank() || workout.workoutType.lowercase(Locale.getDefault()).contains(query) || workout.notes.lowercase(Locale.getDefault()).contains(query)) &&
                (cutoff == null || runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(workout.date)?.after(cutoff) == true }.getOrDefault(false))
            }
            adapter.submitList(filtered)
            binding.emptyHistoryText.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
            binding.historyRecycler.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
        }
        adapter = WorkoutAdapter(
            onClick = { workout ->
                val activity = requireActivity() as MainActivity
                activity.navigateToWorkoutDetail(workout.id)
            },
            onDelete = { workoutId ->
                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    val workouts = adapter.currentList
                    val toDelete = workouts.firstOrNull { it.id == workoutId }
                    if (toDelete != null) {
                        val result = repository.deleteWorkout(toDelete)
                        requireActivity().runOnUiThread {
                            result.onSuccess {
                                Toast.makeText(context, R.string.workout_deleted, Toast.LENGTH_SHORT).show()
                            }.onFailure {
                                Toast.makeText(context, result.exceptionOrNull()?.message ?: "Delete failed", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            },
            onEdit = { workout -> (requireActivity() as MainActivity).editWorkout(workout) }
        )
        binding.historyRecycler.adapter = adapter
        binding.historyRecycler.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(requireContext())

        val userId = repository.currentUser.value?.id ?: return
        repository.getWorkouts(userId).collectInView { workouts ->
            allWorkouts = workouts
            applyFilters()
        }
        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = applyFilters()
            override fun afterTextChanged(s: Editable?) = Unit
        })
        binding.filterButton.setOnClickListener {
            filterDays = when (filterDays) { 0 -> 7; 7 -> 30; else -> 0 }
            binding.filterButton.text = when (filterDays) {
                7 -> getString(R.string.filter_7d)
                30 -> getString(R.string.filter_30d)
                else -> getString(R.string.filter_all)
            }
            applyFilters()
        }
    }
}
