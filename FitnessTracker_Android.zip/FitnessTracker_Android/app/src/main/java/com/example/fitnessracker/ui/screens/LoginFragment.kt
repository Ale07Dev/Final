package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.ui.viewmodel.FitnessViewModel
import com.example.fitnessracker.ui.viewmodel.FitnessViewModelFactory
import com.example.fitnessracker.databinding.FragmentLoginBinding

class LoginFragment : BaseFragment<FragmentLoginBinding>() {

    private lateinit var viewModel: FitnessViewModel
    private var onNavigateToRegister: (() -> Unit) = {}
    private var onLoginSuccess: (() -> Unit) = {}

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentLoginBinding {
        return FragmentLoginBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository
        val factory = FitnessViewModelFactory(repository)
        viewModel = androidx.lifecycle.ViewModelProvider(this, factory)[FitnessViewModel::class.java]

        binding.loginButton.setOnClickListener {
            val email = binding.emailInput.text.toString().trim()
            val password = binding.passwordInput.text.toString().trim()

            if (email.isBlank() || password.isBlank()) {
                Toast.makeText(context, R.string.fill_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(context, R.string.invalid_email, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.login(email, password,
                { message ->
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    onLoginSuccess.invoke()
                },
                { error ->
                    Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                }
            )
        }

        binding.toggleRegisterButton.setOnClickListener { onNavigateToRegister.invoke() }
        binding.guestLoginButton.setOnClickListener {
            val guestUser = viewModel.loginAsGuest()
            Toast.makeText(context, "Logged in as ${guestUser.name}", Toast.LENGTH_SHORT).show()
            onLoginSuccess.invoke()
        }

        binding.resetPasswordText.setOnClickListener {
            val email = binding.emailInput.text.toString().trim()
            if (email.isBlank()) {
                Toast.makeText(context, R.string.reset_email_hint, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewModel.resetPassword(email,
                { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() },
                { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
            )
        }

        binding.googleSignInButton.setOnClickListener {
            Toast.makeText(context, "Google sign-in coming soon", Toast.LENGTH_SHORT).show()
        }
        binding.appleSignInButton.setOnClickListener {
            Toast.makeText(context, "Apple sign-in coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    fun setCallbacks(onNavigateToRegister: () -> Unit, onLoginSuccess: () -> Unit) {
        this.onNavigateToRegister = onNavigateToRegister
        this.onLoginSuccess = onLoginSuccess
    }
}
