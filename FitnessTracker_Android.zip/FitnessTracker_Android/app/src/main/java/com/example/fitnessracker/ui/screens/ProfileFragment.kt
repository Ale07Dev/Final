package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.MainActivity
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.User
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentProfileBinding
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ProfileFragment : BaseFragment<FragmentProfileBinding>() {

    private lateinit var repository: FitnessRepository
    private var isEditing = false

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentProfileBinding {
        return FragmentProfileBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        setEditMode(false)

        repository.currentUser.collectInView { user ->
            if (user == null) return@collectInView
            binding.profileNameText.text = user.name
            binding.profileEmailText.text = user.email
            binding.profileNameInput.setText(user.name)
            binding.profileEmailInput.setText(user.email)
            binding.profileAgeInput.setText(user.age.toString())
            binding.profileWeightInput.setText(user.weightKg.toString())
        }

        binding.profileGoalsButton.setOnClickListener {
            (requireActivity() as MainActivity).navigateToGoals()
        }
        binding.profileSettingsButton.setOnClickListener {
            (requireActivity() as MainActivity).navigateToSettings()
        }

        binding.editProfileButton.setOnClickListener {
            isEditing = true
            setEditMode(true)
        }

        binding.saveProfileButton.setOnClickListener {
            val user = repository.currentUser.value ?: return@setOnClickListener
            val name = binding.profileNameInput.text.toString().trim()
            val email = binding.profileEmailInput.text.toString().trim()
            val age = binding.profileAgeInput.text.toString().toIntOrNull() ?: user.age
            val weight = binding.profileWeightInput.text.toString().toDoubleOrNull() ?: user.weightKg

            if (name.isBlank() || email.isBlank()) {
                Toast.makeText(context, R.string.fill_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                val result = repository.updateUser(user.id, name, email, age, weight)
                requireActivity().runOnUiThread {
                    result.onSuccess {
                        Toast.makeText(context, R.string.save_profile_success, Toast.LENGTH_SHORT).show()
                        isEditing = false
                        setEditMode(false)
                    }.onFailure {
                        Toast.makeText(context, result.exceptionOrNull()?.message ?: "Update failed", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun setEditMode(edit: Boolean) {
        binding.profileNameInput.isEnabled = edit
        binding.profileEmailInput.isEnabled = edit
        binding.profileAgeInput.isEnabled = edit
        binding.profileWeightInput.isEnabled = edit
        binding.saveProfileButton.visibility = if (edit) View.VISIBLE else View.GONE
        binding.editProfileButton.visibility = if (edit) View.GONE else View.VISIBLE
    }
}
