package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.ui.adapter.PersonalRecord
import com.example.fitnessracker.ui.adapter.PersonalRecordAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import android.content.Context
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentProgressBinding
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class ProgressFragment : BaseFragment<FragmentProgressBinding>() {

    private lateinit var repository: FitnessRepository

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentProgressBinding {
        return FragmentProgressBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        val prefs = requireContext().getSharedPreferences("fitness_settings", Context.MODE_PRIVATE)
        val imperial = prefs.getBoolean("units_imperial", false)
        val recordAdapter = PersonalRecordAdapter()
        binding.prRecycler.layoutManager = LinearLayoutManager(requireContext())
        binding.prRecycler.adapter = recordAdapter
        val userId = repository.currentUser.value?.id ?: return
        repository.getWorkouts(userId).collectInView { workouts ->
            val totalWorkouts = workouts.size
            val totalDistance = workouts.sumOf { it.distanceKm ?: 0.0 }
            val totalCalories = workouts.sumOf { it.caloriesBurned }
            val totalMinutes = workouts.sumOf { it.durationMinutes }

            binding.totalWorkoutsText.text = "$totalWorkouts"
            binding.totalDistanceText.text = if (imperial) "%.2f mi".format(totalDistance * 0.621371) else "%.2f km".format(totalDistance)
            binding.totalCaloriesText.text = "$totalCalories kcal"
            binding.totalTimeText.text = "$totalMinutes min"

            val records = mutableListOf<PersonalRecord>()
            val bestDistance = workouts.filter { (it.distanceKm ?: 0.0) > 0.0 }.maxByOrNull { it.distanceKm ?: 0.0 }
            if (bestDistance != null) {
                val distance = bestDistance.distanceKm ?: 0.0
                records += PersonalRecord("Longest distance", if (imperial) "%.2f mi".format(distance * 0.621371) else "%.2f km".format(distance), bestDistance.workoutType + " • " + bestDistance.date)
            }
            val bestCalories = workouts.maxByOrNull { it.caloriesBurned }
            if (bestCalories != null && bestCalories.caloriesBurned > 0) records += PersonalRecord("Most calories burned", "${bestCalories.caloriesBurned} kcal", bestCalories.workoutType + " • " + bestCalories.date)
            val bestDuration = workouts.maxByOrNull { it.durationMinutes }
            if (bestDuration != null && bestDuration.durationMinutes > 0) records += PersonalRecord("Longest workout", "${bestDuration.durationMinutes} min", bestDuration.workoutType + " • " + bestDuration.date)
            recordAdapter.submitList(records)
            binding.prRecycler.visibility = if (records.isEmpty()) View.GONE else View.VISIBLE

            // Streak calculation: consecutive days with workouts ending today
            val workoutDates = workouts.map { it.date }.toSortedSet()
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            var streak = 0
            var cursor = Calendar.getInstance()
            val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cursor.time)
            if (!workoutDates.contains(todayKey)) cursor.add(Calendar.DAY_OF_MONTH, -1)
            while (workoutDates.contains(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cursor.time))) {
                streak++
                cursor.add(Calendar.DAY_OF_MONTH, -1)
            }
            binding.streakText.text = "$streak days"
        }
    }
}
