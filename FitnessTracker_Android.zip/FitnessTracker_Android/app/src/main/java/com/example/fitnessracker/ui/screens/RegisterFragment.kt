package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.ui.viewmodel.FitnessViewModel
import com.example.fitnessracker.ui.viewmodel.FitnessViewModelFactory
import com.example.fitnessracker.databinding.FragmentRegisterBinding

class RegisterFragment : BaseFragment<FragmentRegisterBinding>() {

    private lateinit var viewModel: FitnessViewModel
    private var onNavigateBack: (() -> Unit) = {}
    private var onRegisterSuccess: (() -> Unit) = {}

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentRegisterBinding {
        return FragmentRegisterBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository
        val factory = FitnessViewModelFactory(repository)
        viewModel = androidx.lifecycle.ViewModelProvider(this, factory)[FitnessViewModel::class.java]

        binding.registerButton.setOnClickListener {
            val name = binding.nameInput.text.toString().trim()
            val email = binding.emailInput.text.toString().trim()
            val password = binding.passwordInput.text.toString().trim()
            val confirmPassword = binding.confirmPasswordInput.text.toString().trim()

            if (name.isBlank() || email.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
                Toast.makeText(context, R.string.fill_required, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(context, R.string.invalid_email, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (password.length < 6) {
                Toast.makeText(context, R.string.password_too_short, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (password != confirmPassword) {
                Toast.makeText(context, R.string.passwords_mismatch, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewModel.register(name, email, password,
                { message ->
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    onRegisterSuccess.invoke()
                },
                { error ->
                    Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                }
            )
        }

        binding.toggleLoginButton.setOnClickListener { onNavigateBack.invoke() }
    }

    fun setCallbacks(onNavigateBack: () -> Unit, onRegisterSuccess: () -> Unit) {
        this.onNavigateBack = onNavigateBack
        this.onRegisterSuccess = onRegisterSuccess
    }
}
