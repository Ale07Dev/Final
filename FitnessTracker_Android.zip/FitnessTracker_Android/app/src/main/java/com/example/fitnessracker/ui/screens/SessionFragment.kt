package com.example.fitnessracker.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.fitnessracker.MainActivity
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentSessionBinding
import com.example.fitnessracker.location.GpsTracker
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class SessionFragment : Fragment(), GpsTracker.LocationUpdateListener {

    private var _binding: FragmentSessionBinding? = null
    private val binding get() = _binding!!

    private lateinit var repository: FitnessRepository
    private lateinit var gpsTracker: GpsTracker
    private val handler = Handler(Looper.getMainLooper())
    private val timerRunnable = Runnable { runTimer() }

    private var isSessionRunning = false
    private var isSessionPaused = false
    private var sessionSeconds = 0
    private var currentWorkoutType = "Outdoor Running"
    private var isImperialUnits = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSessionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository
        isImperialUnits = requireContext().getSharedPreferences("fitness_settings", android.content.Context.MODE_PRIVATE).getBoolean("units_imperial", false)
        gpsTracker = GpsTracker(requireContext())
        gpsTracker.listener = this

        binding.pauseWorkoutButton.setOnClickListener {
            if (!isSessionRunning) return@setOnClickListener
            isSessionPaused = !isSessionPaused
            if (isSessionPaused) {
                gpsTracker.pauseTracking()
                binding.pauseWorkoutButton.text = getString(R.string.resume_session)
                Toast.makeText(context, "Session paused", Toast.LENGTH_SHORT).show()
            } else {
                gpsTracker.resumeTracking()
                binding.pauseWorkoutButton.text = getString(R.string.pause_session)
                Toast.makeText(context, "Session resumed", Toast.LENGTH_SHORT).show()
            }
        }

        binding.endWorkoutButton.setOnClickListener {
            if (!isSessionRunning) return@setOnClickListener
            endSession()
        }
    }

    override fun onResume() {
        super.onResume()
        checkAndRequestLocationPermissions()
    }

    private fun startSession() {
        if (isSessionRunning) return
        isSessionRunning = true
        isSessionPaused = false
        sessionSeconds = 0
        binding.pauseWorkoutButton.text = getString(R.string.pause_session)

        gpsTracker.startTracking()
        handler.removeCallbacks(timerRunnable)
        handler.post(timerRunnable)

        binding.sessionGpsStatusText.text = getString(R.string.gps_initializing)
        Toast.makeText(context, R.string.gps_active, Toast.LENGTH_SHORT).show()
    }

    private fun endSession() {
        isSessionRunning = false
        handler.removeCallbacks(timerRunnable)
        gpsTracker.stopTracking()

        val durationMinutes = Math.max(1, sessionSeconds / 60)
        val distanceKm = gpsTracker.totalDistanceKm
        val user = repository.currentUser.value
        val weight = user?.weightKg ?: 70.0
        val calories = repository.calculateCalories(currentWorkoutType, durationMinutes, distanceKm, weight)

        val workout = Workout(
            userId = repository.currentUser.value?.id ?: return,
            workoutType = currentWorkoutType,
            date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
            durationMinutes = durationMinutes,
            distanceKm = distanceKm,
            caloriesBurned = calories,
            notes = "GPS Live Session",
            timestamp = System.currentTimeMillis()
        )

        // Save from the Activity's scope: we navigate away right below, which destroys this
        // fragment's view and would cancel a viewLifecycleOwner-scoped coroutine mid-save.
        val activity = requireActivity() as MainActivity
        val appContext = activity.applicationContext
        val repo = repository
        activity.lifecycleScope.launch {
            val result = repo.addWorkout(workout)
            result.onSuccess {
                Toast.makeText(appContext, "Workout saved! (%.2f km, %d kcal)".format(distanceKm, calories), Toast.LENGTH_LONG).show()
            }.onFailure { e ->
                Toast.makeText(appContext, e.message ?: "Save failed", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate back to history (handled by activity)
        activity.navigateToHistory()
    }

    private fun runTimer() {
        if (isSessionRunning && !isSessionPaused) {
            sessionSeconds++
            updateSessionUi()
        }
        if (isSessionRunning) {
            handler.postDelayed(timerRunnable, 1000L)
        }
    }

    private fun updateSessionUi() {
        val hrs = sessionSeconds / 3600
        val mins = (sessionSeconds % 3600) / 60
        val secs = sessionSeconds % 60
        binding.sessionTimerText.text = String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)

        val distKm = gpsTracker.totalDistanceKm
        val distDisplay = if (isImperialUnits) "%.2f mi".format(distKm * 0.621371) else "%.2f km".format(distKm)
        val durationMin = Math.max(1, sessionSeconds / 60)
        val speedKmH = if (sessionSeconds > 0) (distKm / (sessionSeconds / 3600.0)) else 0.0
        val speedDisplay = if (isImperialUnits) "%.1f mph".format(speedKmH * 0.621371) else "%.1f km/h".format(speedKmH)
        val user = repository.currentUser.value
        val weight = user?.weightKg ?: 70.0
        val calories = repository.calculateCalories(currentWorkoutType, durationMin, distKm, weight)
        binding.sessionStatsText.text = "$distDisplay  •  $speedDisplay  •  $calories kcal"
    }

    override fun onLocationUpdated(location: android.location.Location, currentDistanceKm: Double, pointCount: Int) {
        binding.sessionGpsStatusText.text = getString(R.string.gps_active)
        binding.sessionCoordsText.text = getString(R.string.coordinates, location.latitude, location.longitude)
        // Also append track points info
        binding.sessionStatsText.text = binding.sessionStatsText.text.toString() + "  •  $pointCount points"
        updateSessionUi()
    }

    override fun onGpsStatusChanged(isTracking: Boolean, message: String) {
        binding.sessionGpsStatusText.text = message
    }

    private fun checkAndRequestLocationPermissions() {
        if (isSessionRunning) return
        val fine = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED || coarse != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1001)
        } else {
            startSession()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(context, "Location permission granted", Toast.LENGTH_SHORT).show()
                startSession()
            } else {
                Toast.makeText(context, R.string.location_permission_denied, Toast.LENGTH_SHORT).show()
                startSession() // Still start without GPS
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(timerRunnable)
        gpsTracker.stopTracking()
        _binding = null
    }
}
