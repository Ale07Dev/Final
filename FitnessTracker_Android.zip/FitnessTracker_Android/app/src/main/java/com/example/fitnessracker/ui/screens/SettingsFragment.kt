package com.example.fitnessracker.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.databinding.FragmentSettingsBinding

class SettingsFragment : BaseFragment<FragmentSettingsBinding>() {

    private lateinit var prefs: SharedPreferences
    private val exportCsvLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) writeCsv(uri)
    }

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentSettingsBinding {
        return FragmentSettingsBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        prefs = requireContext().getSharedPreferences("fitness_settings", Context.MODE_PRIVATE)

        val isDark = prefs.getBoolean("dark_mode", false)
        binding.darkModeSwitch.isChecked = isDark

        binding.darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("dark_mode", isChecked).apply()
            applyTheme(isChecked)
        }
        binding.exportButton.setOnClickListener {
            val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
            exportCsvLauncher.launch("fitness_workouts_$date.csv")
        }

        val isImperial = prefs.getBoolean("units_imperial", false)
        binding.unitsImperial.isChecked = isImperial
        binding.unitsMetric.isChecked = !isImperial

        binding.unitsRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            val imperial = checkedId == R.id.unitsImperial
            prefs.edit().putBoolean("units_imperial", imperial).apply()
        }

        binding.settingsLogoutButton.setOnClickListener {
            val activity = requireActivity()
            val app = activity.application as com.example.fitnessracker.FitnessApp
            app.repository.logout()
            // Navigate back to login - handled by activity
            val nav = activity as com.example.fitnessracker.MainActivity
            nav.navigateToLogin()
        }
    }


    private fun writeCsv(uri: Uri) {
        val app = requireActivity().application as com.example.fitnessracker.FitnessApp
        val userId = app.repository.currentUser.value?.id
        if (userId == null) { Toast.makeText(requireContext(), "Please sign in before exporting.", Toast.LENGTH_SHORT).show(); return }
        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val workouts = app.repository.getWorkouts(userId).first()
                    requireContext().contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { out ->
                        out.appendLine("id,user_id,workout_type,date,duration_minutes,distance_km,calories_burned,notes,rpe,location_name,latitude,longitude,timestamp")
                        workouts.forEach { w ->
                            val fields = listOf(w.id.toString(), w.userId.toString(), w.workoutType, w.date, w.durationMinutes.toString(), w.distanceKm?.toString() ?: "", w.caloriesBurned.toString(), w.notes, w.rpe?.toString() ?: "", w.locationName ?: "", w.latitude?.toString() ?: "", w.longitude?.toString() ?: "", w.timestamp.toString())
                            out.appendLine(fields.joinToString(",") { csvEscape(it) })
                        }
                    } ?: error("Unable to open destination file")
                }
            }
            result.onSuccess { Toast.makeText(requireContext(), "Workout CSV exported successfully.", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(requireContext(), "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    private fun applyTheme(isDark: Boolean) {
        val mode = if (isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        AppCompatDelegate.setDefaultNightMode(mode)
    }
}
