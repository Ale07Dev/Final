package com.example.fitnessracker.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.fitnessracker.R
import com.example.fitnessracker.data.model.Workout
import com.example.fitnessracker.data.repository.FitnessRepository
import com.example.fitnessracker.databinding.FragmentWorkoutDetailBinding
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WorkoutDetailFragment : BaseFragment<FragmentWorkoutDetailBinding>() {

    private lateinit var repository: FitnessRepository
    private var workoutId: Long = 0
    private var onDeleteConfirmed: (() -> Unit) = {}
    private var onEditRequested: ((Workout) -> Unit) = {}

    override fun createBinding(inflater: LayoutInflater, container: ViewGroup?, attachToParent: Boolean): FragmentWorkoutDetailBinding {
        return FragmentWorkoutDetailBinding.inflate(inflater, container, attachToParent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        repository = (requireActivity().application as com.example.fitnessracker.FitnessApp).repository

        val args = arguments
        workoutId = args?.getLong("workout_id", 0) ?: 0

        val userId = repository.currentUser.value?.id ?: return
        repository.getWorkouts(userId).collectInView { workouts ->
            val workout = workouts.firstOrNull { it.id == workoutId }
            if (workout == null) return@collectInView
            bindWorkout(workout)
        }

        binding.detailEditButton.setOnClickListener {
            val workout = workoutsSnapshot.firstOrNull { it.id == workoutId }
            if (workout != null) {
                onEditRequested.invoke(workout)
            }
        }

        binding.detailDeleteButton.setOnClickListener {
            val workout = workoutsSnapshot.firstOrNull { it.id == workoutId }
            if (workout != null) {
                confirmDelete(workout)
            }
        }

        binding.detailDoneButton.setOnClickListener {
            requireActivity().onBackPressed()
        }
    }

    private val workoutsSnapshot = mutableListOf<Workout>()

    private fun bindWorkout(workout: Workout) {
        workoutsSnapshot.clear()
        workoutsSnapshot.add(workout)

        binding.detailWorkoutName.text = workout.workoutType
        binding.detailWorkoutDate.text = workout.date
        binding.detailDuration.text = "${workout.durationMinutes} min"
        val imperial = requireContext().getSharedPreferences("fitness_settings", android.content.Context.MODE_PRIVATE).getBoolean("units_imperial", false)
        val distance = workout.distanceKm ?: 0.0
        binding.detailDistance.text = if (imperial) "%.2f mi".format(distance * 0.621371) else "%.2f km".format(distance)
        binding.detailCalories.text = "${workout.caloriesBurned} kcal"
        binding.detailRpe.text = workout.rpe?.toString() ?: "—"
        binding.detailLocation.text = workout.locationName ?: "—"
        binding.detailNotes.text = if (workout.notes.isNotBlank()) workout.notes else "No notes"
    }

    private fun confirmDelete(workout: Workout) {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(R.string.confirm_delete)
            .setPositiveButton(R.string.yes) { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    val result = repository.deleteWorkout(workout)
                    requireActivity().runOnUiThread {
                        result.onSuccess {
                            Toast.makeText(context, R.string.workout_deleted, Toast.LENGTH_SHORT).show()
                            onDeleteConfirmed.invoke()
                        }.onFailure {
                            Toast.makeText(context, result.exceptionOrNull()?.message ?: "Delete failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton(R.string.no) { _, _ -> }
            .create()
        dialog.show()
    }

    fun setCallbacks(
        onDeleteConfirmed: () -> Unit,
        onEditRequested: (Workout) -> Unit
    ) {
        this.onDeleteConfirmed = onDeleteConfirmed
        this.onEditRequested = onEditRequested
    }
}
