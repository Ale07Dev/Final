package com.example.fitnessracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fitnessracker.data.repository.FitnessRepository
import kotlinx.coroutines.launch

class FitnessViewModel(private val repository: FitnessRepository) : ViewModel() {

    fun login(email: String, password: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.login(email, password)
            result.fold(
                onSuccess = { user -> onSuccess.invoke("Welcome back, ${user.name}!") },
                onFailure = { e -> onError.invoke(e.message ?: "Login failed.") }
            )
        }
    }

    fun register(name: String, email: String, password: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.register(name, email, password)
            result.fold(
                onSuccess = { user -> onSuccess.invoke("Account created! Welcome, ${user.name}.") },
                onFailure = { e -> onError.invoke(e.message ?: "Registration failed.") }
            )
        }
    }

    fun resetPassword(email: String, onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.resetPassword(email)
            result.fold(
                onSuccess = { _ -> onSuccess.invoke("Password reset link sent to $email.") },
                onFailure = { e -> onError.invoke(e.message ?: "Password reset failed.") }
            )
        }
    }

    fun logout() {
        repository.logout()
    }

    fun loginAsGuest() = repository.loginAsGuest()
}
