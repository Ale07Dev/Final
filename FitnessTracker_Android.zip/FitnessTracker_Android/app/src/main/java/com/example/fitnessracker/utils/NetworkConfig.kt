package com.example.fitnessracker.utils

import com.example.fitnessracker.BuildConfig

/**
 * Centralized network configuration.
 *
 * The API base URL is read from BuildConfig (set in build.gradle.kts) and can be
 * overridden per build variant or via local.properties to support different
 * network IP addresses (e.g., emulator vs physical phone on the same Wi-Fi).
 *
 * The manifest currently permits cleartext traffic for local development. Use HTTPS in production.
 */
object NetworkConfig {
    val BASE_URL: String = BuildConfig.API_BASE_URL
}
