# Profile update endpoint

Copy `update_profile.php` into the same directory as the other PHP endpoints and adapt `require_once __DIR__ . '/db.php'` to the existing database bootstrap. The bootstrap must create a PDO connection named `$pdo`. The sample expects `users(id, username, email, age, weight_kg)`; align column names with the existing database. The Android client sends a JSON `PUT` request to `update_profile.php` and expects `{ "success": true, "message": "..." }`.

Before production deployment, require authenticated sessions/tokens and derive the user ID from the authenticated identity rather than trusting `user_id` from the request. Use HTTPS in production.
