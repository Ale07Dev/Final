<?php
/**
 * Install as update_profile.php beside the app's other PHP API endpoints.
 * Requires the existing database bootstrap to provide a PDO instance in $pdo.
 * Contract: PUT JSON {"user_id":1,"username":"...","email":"...","age":30,"weight_kg":70.0}
 * Response: {"success":true,"message":"Profile updated"}
 *
 * IMPORTANT: in production derive the user ID from an authenticated session/token,
 * not from the request body. This endpoint follows the existing app's user_id contract.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    header('Allow: PUT');
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}
require_once __DIR__ . '/db.php'; // Must create $pdo as a PDO connection.
$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON body']);
    exit;
}
$userId = filter_var($payload['user_id'] ?? null, FILTER_VALIDATE_INT);
$username = trim((string)($payload['username'] ?? ''));
$email = trim((string)($payload['email'] ?? ''));
$age = filter_var($payload['age'] ?? null, FILTER_VALIDATE_INT);
$weightKg = filter_var($payload['weight_kg'] ?? null, FILTER_VALIDATE_FLOAT);
if (!$userId || $username === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $age === false || $age < 1 || $age > 120 || $weightKg === false || $weightKg <= 0 || $weightKg > 500) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Valid user_id, username, email, age and weight_kg are required']);
    exit;
}
try {
    // Adjust table/column names if the existing backend schema differs.
    $stmt = $pdo->prepare('UPDATE users SET username = :username, email = :email, age = :age, weight_kg = :weight_kg WHERE id = :id');
    $stmt->execute([':username' => $username, ':email' => $email, ':age' => $age, ':weight_kg' => $weightKg, ':id' => $userId]);
    if ($stmt->rowCount() === 0) {
        $check = $pdo->prepare('SELECT id FROM users WHERE id = :id');
        $check->execute([':id' => $userId]);
        if (!$check->fetch(PDO::FETCH_ASSOC)) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'User not found']);
            exit;
        }
    }
    echo json_encode(['success' => true, 'message' => 'Profile updated']);
} catch (PDOException $e) {
    http_response_code($e->getCode() === '23000' ? 409 : 500);
    echo json_encode(['success' => false, 'message' => $e->getCode() === '23000' ? 'Email is already in use' : 'Unable to update profile']);
}
