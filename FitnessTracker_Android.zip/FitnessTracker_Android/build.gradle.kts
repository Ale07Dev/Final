// Top-level build file. Plugin versions come from gradle/libs.versions.toml and are only
// declared here (apply false) so every module shares one classpath. Repositories live in
// settings.gradle.kts (dependencyResolutionManagement), not here.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.kapt) apply false
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
